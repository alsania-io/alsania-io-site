# NYX Control - macOS Setup

**Includes Nyx Control v4.0.4 + local MCP server.**

---

## ⚠️ READ THIS FIRST — IMPORTANT WARNING AND DISCLAIMER

**This package gives AI assistants real access to your computer.**

By installing and using NYX you acknowledge and agree that:

- **You use this software entirely at your own risk.** It is provided "AS IS", without warranty of any kind, express or implied, including but not limited to warranties of merchantability, fitness for a particular purpose, and non-infringement.
- **Alsania I/O is not liable for any damages** — including but not limited to data loss, file corruption, deleted files, system damage, security incidents, financial loss, or any direct, indirect, incidental, special, consequential, or punitive damages — arising from the installation, use, or misuse of this software or from any action taken by an AI model or MCP tool.
- **Desktop Commander can execute real system commands.** This includes creating, modifying, and deleting files, and running programs with your user privileges. An AI model can and will make mistakes. **Always review what an AI is about to do before allowing it to run.**
- **Playwright can control a web browser.** Do not use it while signed into accounts you would not want automated, and do not point it at sensitive services.
- **You are responsible for your own backups.** Keep backups of anything important before granting AI tools access to a directory.
- **You are responsible for complying with all applicable laws** and the terms of service of any platform you use this software with.

If you do not accept these terms, **do not install or use this software.** Delete the package.

---

## Quick Start

1. **Open Terminal** (Applications → Utilities → Terminal).
2. **Make the setup script executable and run it:**
   ```bash
   chmod +x mac-setup.sh
   ./mac-setup.sh
   ```
3. **Install the browser extension** (see *Browser Installation* below).
4. **Start NYX:** double-click `nyx-start.command` in `~/Desktop/nyx/`.
5. **Connect:** click the NYX extension icon in your browser and connect to the local server.

## Browser Installation

The extension lives in the `chrome-extension/` folder inside this package. **Keep that folder somewhere permanent** — if you move or delete it, the extension breaks.

### Chrome / Chromium / Edge (recommended)

1. Open your browser and go to `chrome://extensions/`
   (on Edge: `edge://extensions/`)
2. Turn on **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `chrome-extension` **folder** from this package (not a file inside it)
5. The NYX icon appears in your toolbar

> Chrome may show a "Disable developer mode extensions" warning on restart. This is normal for unpacked extensions — click **Keep** / **Cancel** to keep NYX enabled. Do not click "Disable".

### Firefox

1. Open Firefox and go to `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on…**
3. Select the `manifest.json` file **inside** the `chrome-extension` folder
4. NYX loads for this session

> **Firefox note:** temporarily loaded add-ons are removed when Firefox closes. You must reload it each session. This is a Firefox restriction for unpacked extensions, not a bug in NYX.

### Which browsers are not supported

Safari and most mobile browsers do **not** support unpacked extensions. If you want NYX on a phone, use the separate **Nyx Mobile** package with Firefox Mobile.

### macOS Gatekeeper

If macOS blocks the script ("cannot be opened because it is from an unidentified developer"):
1. Right-click `mac-setup.sh` → **Open**
2. Click **Open** in the dialog

Or clear the quarantine flag:
```bash
xattr -d com.apple.quarantine mac-setup.sh
```

## Detailed Steps

### Prerequisites
- A supported browser (Chrome, Chromium, Edge, or Firefox)
- **Node.js 18+** (checked by the setup script)
- Terminal access

### What the setup script does
1. Checks for a supported browser and Node.js
2. Creates the `~/Desktop/nyx` directory
3. Writes a `config.json` with filesystem access **restricted to `~/Desktop/nyx` only**
4. Creates `nyx-start.command` and `nyx-stop.command` (double-clickable)

### Running the server

**Start:** double-click `nyx-start.command` in `~/Desktop/nyx/`

**Stop:** double-click `nyx-stop.command` in `~/Desktop/nyx/`, or press `Ctrl+C` in its Terminal window

**From the terminal:**
```bash
cd ~/Desktop/nyx
./nyx-start.command
```

## Security

- Filesystem access is **restricted to `~/Desktop/nyx`** — the MCP filesystem server is not given access to your home directory or system files.
- All MCP servers run with **your normal user privileges**. They do not run as root.
- **Desktop Commander still has real system access** within that scope and can run commands. Review AI actions before approving them.
- Never run the setup or start script with `sudo`.

## Troubleshooting

### "Permission denied" when running the script
```bash
chmod +x mac-setup.sh
./mac-setup.sh
```

### Node.js not found
Install with Homebrew:
```bash
brew install node
```
Or download from [nodejs.org](https://nodejs.org/)

### Browser does not find the extension
- Make sure you selected the **folder** `chrome-extension`, not a file inside it
- Confirm `chrome-extension/manifest.json` exists
- For Firefox, load `manifest.json`, not the folder

### Server will not start
- Check Node: `node --version` (must be 18 or newer)
- Make sure no other process is using the same port
- Check firewall settings allow local connections

## Manual command

If the scripts do not work, run the server directly:
```bash
cd ~/Desktop/nyx
npx -y @alsania-io/mcpnyx@latest --config config.json --outputTransport streamableHttp
```

## Included tools

- **Filesystem** — file access restricted to `~/Desktop/nyx`
- **Desktop Commander** (`@wonderwhy-er/desktop-commander`) — system commands and file operations
- **Playwright** (`@playwright/mcp`) — browser automation (runs **headless** by default; edit `config.json` and remove `--headless` to watch it work)
- **Memory Cache** — store and recall information
- **Sequential Thinking** — structured problem-solving
- **Context7** — documentation lookup

## Support

Issues and questions: contact the Alsania development team.

---
**NYX Control — macOS Package**
*Bundles Nyx Control v4.0.4 — Alsania I/O sovereign AI infrastructure*
*Use at your own risk. See the warning at the top of this file.*
