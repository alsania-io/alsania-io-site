#!/bin/bash

echo "=============================================="
echo "  NYX MCP Server - macOS"
echo "=============================================="
echo
echo "This is the packaged start script."
echo "Please run mac-setup.sh first to install NYX properly."
echo
echo "If you have already run mac-setup.sh:"
echo "1. The proper start script is at: ~/Desktop/nyx/nyx-start.command"
echo "2. Double-click that file to start NYX"
echo
echo "If you haven't run setup:"
echo "1. Open Terminal"
echo "2. Navigate to this directory"
echo "3. Run: ./mac-setup.sh"
echo
read -p "Press Enter to close this window..."
