#!/bin/bash

echo "=============================================="
echo "  NYX MCP Server - Stop Script (Package)"
echo "=============================================="
echo
echo "This is the packaged stop script."
echo "After running mac-setup.sh, the proper stop script"
echo "will be at: ~/Desktop/nyx/nyx-stop.command"
echo
echo "To stop NYX after setup:"
echo "1. Double-click ~/Desktop/nyx/nyx-stop.command"
echo "2. Or run in Terminal: pkill -f \"npx.*mcpnyx\""
echo
read -p "Press Enter to close this window..."
