#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}==============================================${NC}"
echo -e "${BLUE}   NYX MCP Setup for Linux${NC}"
echo -e "${BLUE}==============================================${NC}"
echo

echo -e "${BLUE}1. Checking for Chrome/Chromium browser...${NC}"
if command -v google-chrome &> /dev/null; then
    echo -e "  ${GREEN}✓ Google Chrome detected${NC}"
elif command -v chromium-browser &> /dev/null; then
    echo -e "  ${GREEN}✓ Chromium browser detected${NC}"
elif command -v chromium &> /dev/null; then
    echo -e "  ${GREEN}✓ Chromium detected${NC}"
elif command -v microsoft-edge &> /dev/null; then
    echo -e "  ${GREEN}✓ Microsoft Edge detected${NC}"
elif command -v firefox &> /dev/null; then
    echo -e "  ${GREEN}✓ Firefox detected${NC}"
else
    echo -e "  ${YELLOW}⚠ No supported browser found in PATH${NC}"
    echo -e "  NYX supports Chrome, Chromium, Edge, or Firefox. Install one:"
    echo -e "  Ubuntu/Debian: sudo apt install chromium-browser   (or: sudo apt install firefox)"
    echo -e "  Fedora: sudo dnf install chromium                  (or: sudo dnf install firefox)"
    echo -e "  Arch: sudo pacman -S chromium                      (or: sudo pacman -S firefox)"
    echo -e "  Or download from: https://www.google.com/chrome/"
    read -p "Press Enter to continue..."
fi

echo

echo -e "${BLUE}2. Installing NYX Chrome extension...${NC}"
echo -e "  Please follow these steps manually:"
echo -e "  Chrome/Chromium/Edge:"
echo -e "  1. Go to: chrome://extensions/   (Edge: edge://extensions/)"
echo -e "  2. Enable \"Developer mode\" (top-right toggle)"
echo -e "  3. Click \"Load unpacked\""
echo -e "  4. Select the \"chrome-extension\" folder in this package"
echo -e "  Firefox:"
echo -e "  1. Go to: about:debugging#/runtime/this-firefox"
echo -e "  2. Click \"Load Temporary Add-on...\""
echo -e "  3. Select manifest.json inside the chrome-extension folder"

if [[ -d "chrome-extension" ]]; then
    echo -e "  ${GREEN}✓ Extension folder found in package${NC}"
else
    echo -e "  ${YELLOW}⚠ Extension folder not found in package${NC}"
    echo -e "  You may need to download it separately"
fi

echo

echo -e "${BLUE}3. Setting up NYX directory on Desktop...${NC}"
NYX_DIR="$HOME/Desktop/nyx"

if [[ ! -d "$NYX_DIR" ]]; then
    mkdir -p "$NYX_DIR"
    echo -e "  ${GREEN}✓ Created nyx directory: $NYX_DIR${NC}"
else
    echo -e "  ${GREEN}✓ NYX directory already exists: $NYX_DIR${NC}"
fi

echo

echo -e "${BLUE}4. Checking for Node.js and npm...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version | cut -d'v' -f2)
    MAJOR_VERSION=$(echo $NODE_VERSION | cut -d'.' -f1)
    if [[ $MAJOR_VERSION -ge 18 ]]; then
        echo -e "  ${GREEN}✓ Node.js $NODE_VERSION detected (18+ required)${NC}"
    else
        echo -e "  ${RED}❌ Node.js $NODE_VERSION detected (18+ required)${NC}"
        echo -e "  Please update Node.js:"
        echo -e "  Using nvm: nvm install 20 && nvm use 20"
        echo -e "  Or via package manager"
        read -p "Press Enter to continue..."
    fi
else
    echo -e "  ${RED}❌ Node.js not found. Please install Node.js 18+${NC}"
    echo -e "  Recommended: Install nvm, then Node.js 20:"
    echo -e "  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash"
    echo -e "  source ~/.bashrc"
    echo -e "  nvm install 20"
    echo -e "  nvm use 20"
    echo -e "  Or download from: https://nodejs.org/"
    read -p "Press Enter to continue..."
fi

if command -v npm &> /dev/null; then
    echo -e "  ${GREEN}✓ npm detected${NC}"
else
    echo -e "  ${YELLOW}⚠ npm not found (but Node.js may be installed)${NC}"
fi

echo

echo -e "${BLUE}5. Setting up configuration...${NC}"
if [[ ! -f "config.json" ]]; then
    echo -e "  ${RED}❌ config.json not found in package${NC}"
    echo -e "  Please ensure config.json exists in this directory"
    read -p "Press Enter to continue..."
    exit 1
fi

# Replace placeholder with absolute path
CONFIG_FILE="$NYX_DIR/config.json"
sed "s|NYX_DIR_PLACEHOLDER|$NYX_DIR|g" config.json > "$CONFIG_FILE"

echo -e "  ${GREEN}✓ Created config.json with absolute path: $NYX_DIR${NC}"
echo -e "  ${GREEN}✓ Filesystem access restricted to this directory only${NC}"

echo

echo -e "${BLUE}6. Creating start and stop scripts...${NC}"

# Create start script
cat > "$NYX_DIR/nyx-start.sh" << 'EOF'
#!/bin/bash

echo "=============================================="
echo "  NYX MCP Server - Linux"
echo "=============================================="
echo
cd "$HOME/Desktop/nyx"
npx -y @alsania-io/mcpnyx@latest --config config.json --outputTransport streamableHttp
EOF
chmod +x "$NYX_DIR/nyx-start.sh"
echo -e "  ${GREEN}✓ Created nyx-start.sh${NC}"

# Create stop script
cat > "$NYX_DIR/nyx-stop.sh" << 'EOF'
#!/bin/bash
echo "Stopping NYX MCP Server..."
pkill -f "npx.*mcpnyx" 2>/dev/null
echo "NYX server stopped."
sleep 2
EOF
chmod +x "$NYX_DIR/nyx-stop.sh"
echo -e "  ${GREEN}✓ Created nyx-stop.sh${NC}"

echo
echo -e "${BLUE}7. Creating desktop entry...${NC}"
cat > "$NYX_DIR/nyx.desktop" << EOF
[Desktop Entry]
Type=Application
Name=NYX MCP Server
Comment=Start the NYX MCP server
Exec=bash -c 'cd $NYX_DIR && ./nyx-start.sh'
Icon=utilities-terminal
Terminal=true
Categories=Development;
EOF
chmod +x "$NYX_DIR/nyx.desktop"
mkdir -p "$HOME/.local/share/applications"
cp "$NYX_DIR/nyx.desktop" "$HOME/.local/share/applications/nyx.desktop" 2>/dev/null || true
echo -e "  ${GREEN}✓ Desktop entry created${NC}"

echo
echo -e "${BLUE}==============================================${NC}"
echo -e "${GREEN} SETUP COMPLETE${NC}"
echo -e "${BLUE}==============================================${NC}"
echo
echo "Next steps:"
echo "1. Install the NYX extension in your browser (see step 2 above)"
echo "2. Start the server:  cd ~/Desktop/nyx && ./nyx-start.sh"
echo "3. Connect the extension to the local server"
echo
echo "Security configuration:"
echo "• Filesystem access restricted to: $NYX_DIR"
echo "• All MCP servers run with normal user privileges (never as root)"
echo
echo "Manual start:  cd ~/Desktop/nyx && ./nyx-start.sh"
echo "Manual stop:   cd ~/Desktop/nyx && ./nyx-stop.sh"
echo
read -p "Press Enter to finish setup..."
