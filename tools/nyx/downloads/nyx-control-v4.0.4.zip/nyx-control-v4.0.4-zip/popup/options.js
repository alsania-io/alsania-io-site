
'use strict';

const $ = id => document.getElementById(id);

// Simple Toast Notification for Options Page
function showToast(message, type = 'success') {
  let toastEl = $('toast');
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.id = 'toast';
    document.body.appendChild(toastEl);
  }

  toastEl.textContent = message;
  toastEl.className = `toast-show ${type}`;

  // Basic styling applied dynamically for the toast
  Object.assign(toastEl.style, {
    position: 'fixed', bottom: '20px', right: '20px',
    padding: '10px 20px', background: type === 'success' ? 'rgba(0, 247, 255, 0.2)' : 'rgba(255, 77, 109, 0.2)',
    border: `1px solid ${type === 'success' ? 'var(--neon-teal)' : '#ff4d6d'}`,
    color: '#fff', borderRadius: '8px', zIndex: '1000',
    boxShadow: '0 0 10px rgba(0,0,0,0.5)'
  });

  setTimeout(() => toastEl.remove(), 3000);
}

// ── LOAD SAVED SETTINGS ──
async function loadSettings() {
  const data = await chrome.storage.local.get(['apiProvider', 'apiKey', 'defaultModel']);

  if (data.apiProvider) $('api-provider').value = data.apiProvider;
  if (data.apiKey) $('api-key').value = data.apiKey;

  // Fetch models based on loaded provider BEFORE setting the default model
  await fetchDynamicModels();

  if (data.defaultModel) {
    $('default-model').value = data.defaultModel;
  }
}

// ── DYNAMIC MODEL FETCHING (OPTIONS) ──
async function fetchDynamicModels() {
  const provider = $('api-provider').value;
  const modelSelect = $('default-model');

  modelSelect.innerHTML = '<option value="">— Loading Models... —</option>';
  modelSelect.disabled = true;

  let models = [];

  try {
    if (provider === 'openrouter') {
      const response = await fetch('https://openrouter.ai/api/v1/models');
      const data = await response.json();
      // Map to standard format
      models = data.data.map(m => ({ id: m.id, name: m.name }));
    } else if (provider === 'kilocode') {
      // Logic/Mock for Kilocode or other registries
      models = [
        { id: 'claude-3-5-sonnet', name: 'Claude 3.5 Sonnet (Kilocode)' },
        { id: 'claude-3-5-haiku', name: 'Claude 3.5 Haiku (Kilocode)' }
      ];
    }

    // Populate the dropdown dynamically
    modelSelect.innerHTML = models.map(m =>
      `<option value="${m.id}">${m.name}</option>`
    ).join('');
  } catch (error) {
    modelSelect.innerHTML = '<option value="">Error loading models</option>';
    console.error("Nyx: Failed to fetch models:", error);
  } finally {
    modelSelect.disabled = false;
  }
}

// ── EVENT LISTENERS ──

// Re-fetch models immediately if the user changes the provider
$('api-provider').addEventListener('change', fetchDynamicModels);

// Save settings to Chrome storage
$('save-api').addEventListener('click', async () => {
  const settings = {
    apiProvider: $('api-provider').value,
    apiKey: $('api-key').value,
    defaultModel: $('default-model').value
  };

  await chrome.storage.local.set(settings);

  // Optional: Notify background script that settings changed
  try {
    chrome.runtime.sendMessage({ action: 'settingsUpdated', settings });
  } catch(e) { /* Ignore if background script isn't active */ }

  showToast('API Settings saved successfully! ✓');
});

// Initialize the page
document.addEventListener('DOMContentLoaded', loadSettings);