/**
 * popup/script.js
 * Nyx Control Hub — Popup Controller
 * Wires all tabs, MCP quick-connect, server management, chat, swarm.
 * Communicates with background.js via chrome.runtime.sendMessage.
 * Aligned with Alsania AI Protocol v1.0
 */

'use strict';

// ── Helpers ───────────────────────────────────────────────────────────────────

const msg  = (data) => chrome.runtime.sendMessage(data);
const $    = (id)   => document.getElementById(id);
const qs   = (sel)  => document.querySelector(sel);
const qsa  = (sel)  => [...document.querySelectorAll(sel)];

function toast(text, type = 'info', ms = 2600) {
  const wrap = $('toast-wrap');
  const el   = document.createElement('div');
  el.className   = `toast toast-${type}`;
  el.textContent = text;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), ms);
}

function setDot(dotEl, state) {
  dotEl.className = `status-dot ${state}`;             // state: '', 'connecting', 'error', 'off'
}

function showError(elId, msg) {
  const el = $(elId);
  if (!el) return;
  el.textContent = msg;
  el.classList.add('visible');
  setTimeout(() => el.classList.remove('visible'), 4000);
}

// ── Tab routing ───────────────────────────────────────────────────────────────

qsa('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    qsa('.tab').forEach(t => t.classList.remove('active'));
    qsa('.tab-content').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;
    $(`${tab}Tab`).classList.add('active');
    $('search-wrap').style.display = tab === 'tools' ? 'block' : 'none';
  });
});

// ── State ─────────────────────────────────────────────────────────────────────

const state = {
  settings:   {},
  servers:    [],
  connected:  {},           // serverName → true/false
  tools:      [],
  editIndex:  -1,
  qsEnv:      {},           // quick-setup env vars
  qsArgs:     [],           // quick-setup args
  svEnv:      {},           // add-server-panel env vars
  svArgs:     [],           // add-server-panel args
  swarmRunning: false,
};

// ── Init ──────────────────────────────────────────────────────────────────────

(async function init() {
  const [settingsRes, serversRes] = await Promise.all([
    msg({ action: 'getSettings'   }),
    msg({ action: 'getMcpServers' }),
  ]);

  state.settings = settingsRes.settings || {};
  state.servers  = serversRes.servers   || [];

  applySettings();
  renderServers();
  populateModelSelect();
  checkCurrentSite();
})();

// ── Settings ──────────────────────────────────────────────────────────────────

function applySettings() {
  const s = state.settings;
  if ($('api-provider'))    $('api-provider').value   = s.apiProvider  || 'openrouter';
  if ($('api-key'))         $('api-key').value        = s.apiKey       || '';
  if ($('default-model'))   $('default-model').value  = s.model        || '';
  if ($('toggle-inject'))   $('toggle-inject').checked   = s.siteInject  ?? true;
  if ($('toggle-autosend')) $('toggle-autosend').checked = s.autoSend    ?? false;
  if ($('toggle-voice'))    $('toggle-voice').checked    = s.voiceEnabled ?? false;
  if ($('toggle-debug'))    $('toggle-debug').checked    = s.debug        ?? false;
  if ($('wake-word'))       $('wake-word').value       = s.wakeWord     || 'Hey Nyx';
  toggleWakeWordField();
}

$('toggle-voice').addEventListener('change', toggleWakeWordField);
function toggleWakeWordField() {
  $('wake-word-group').style.display = $('toggle-voice').checked ? 'block' : 'none';
}

$('save-api-btn').addEventListener('click', saveSettings);
$('save-settings-btn').addEventListener('click', saveSettings);

async function saveSettings() {
  const s = {
    apiProvider:  $('api-provider').value,
    apiKey:       $('api-key').value.trim(),
    model:        $('default-model').value,
    siteInject:   $('toggle-inject').checked,
    autoSend:     $('toggle-autosend').checked,
    voiceEnabled: $('toggle-voice').checked,
    wakeWord:     $('wake-word').value.trim(),
    debug:        $('toggle-debug').checked,
  };
  state.settings = s;
  await msg({ action: 'saveSettings', settings: s });
  populateModelSelect();
  toast('Settings saved ✓', 'success');
}

function populateModelSelect() {
  const s     = state.settings;
  const sel   = $('model-select');
  const opts  = {
    openrouter: [
      ['meta-llama/llama-3.1-8b-instruct:free',  'Llama 3.1 8B (free)'],
      ['meta-llama/llama-3.3-70b-instruct:free',  'Llama 3.3 70B (free)'],
      ['qwen/qwen-2.5-7b-instruct:free',          'Qwen 2.5 7B (free)'],
      ['mistralai/mistral-7b-instruct:free',       'Mistral 7B (free)'],
      ['google/gemma-2-9b-it:free',               'Gemma 2 9B (free)'],
    ],
    kilocode: [
      ['claude-3-5-sonnet', 'Claude 3.5 Sonnet'],
      ['claude-3-5-haiku',  'Claude 3.5 Haiku'],
    ],
  };
  const list = opts[s.apiProvider] || opts.openrouter;
  sel.innerHTML = list.map(([v, l]) =>
    `<option value="${v}" ${v === (s.model || list[0][0]) ? 'selected' : ''}>${l}</option>`
  ).join('');
}

// ── Current site detection ─────────────────────────────────────────────────────

async function checkCurrentSite() {
  const res = await msg({ action: 'getSiteInfo' });
  const badge = $('site-badge');
  if (res.success && res.site) {
    badge.textContent = res.site.name;
    badge.style.display = 'inline-flex';
  } else {
    badge.style.display = 'none';
  }
}

// ── Chat ──────────────────────────────────────────────────────────────────────

$('send-btn').addEventListener('click', sendChat);
$('chat-input').addEventListener('keydown', e => {
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) sendChat();
});

async function sendChat() {
  const input = $('chat-input');
  const text  = input.value.trim();
  if (!text) return;

  addMessage(text, 'user');
  input.value = '';
  $('send-btn').disabled = true;

  try {
    const model = $('model-select').value;
    const res   = await msg({ action: 'sendToAI', data: { message: text, model } });
    if (res.success) {
      addMessage(res.data.response, 'assistant');
    } else {
      addMessage(`Error: ${res.error}`, 'error');
    }
  } catch (err) {
    addMessage(`Error: ${err.message}`, 'error');
  } finally {
    $('send-btn').disabled = false;
  }
}

function addMessage(text, role) {
  const msgs = $('messages');
  const div  = document.createElement('div');
  div.className = `msg msg-${role}`;

  if (role === 'user') {
    div.innerHTML = `<div class="msg-avatar">👤</div><div class="msg-body">${esc(text)}</div>`;
  } else if (role === 'assistant') {
    div.innerHTML = `<div class="msg-avatar">⬡</div><div class="msg-body">${esc(text)}</div>`;
  } else if (role === 'error') {
    div.innerHTML = `<div class="msg-body" style="color:var(--danger)">⚠ ${esc(text)}</div>`;
  }

  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

$('clear-chat').addEventListener('click', () => {
  $('messages').innerHTML = '<div class="msg msg-system">⬡ Chat cleared.</div>';
});

// ── MCP action bar ────────────────────────────────────────────────────────────

qsa('.mcp-pill').forEach(btn => {
  btn.addEventListener('click', async () => {
    const action = btn.dataset.action;
    const res    = await msg({ action: `mcp${action.charAt(0).toUpperCase() + action.slice(1)}` });
    if (res?.success) {
      if (action === 'attach' || action === 'copy') {
        if (res.content) addMessage(`[${action}] ${res.content.slice(0, 200)}`, 'assistant');
      } else {
        toast(`${action} ✓`, 'success');
      }
    } else {
      toast(res?.error || `${action} failed`, 'error');
    }
  });
});

// ── Tools tab (real tools from MCP) ───────────────────────────────────────────

$('searchInput').addEventListener('input', e => renderTools(e.target.value.toLowerCase()));

function renderTools(query = '') {
  const grid  = $('toolsGrid');
  const count = $('toolsCount');

  const filtered = query
    ? state.tools.filter(t => t.name.toLowerCase().includes(query) || (t.description || '').toLowerCase().includes(query))
    : state.tools;

  count.textContent = `${filtered.length} tool${filtered.length !== 1 ? 's' : ''}`;

  if (filtered.length === 0) {
    grid.innerHTML = `<div class="empty-state">
      <div class="empty-icon"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
      <div>${state.tools.length === 0 ? 'Connect an MCP server to see tools' : 'No tools match'}</div>
    </div>`;
    return;
  }

  grid.innerHTML = '';
  filtered.forEach(tool => {
    const card = document.createElement('div');
    card.className = 'tool-card';
    const params = tool.inputSchema?.properties || {};
    const reqd   = tool.inputSchema?.required   || [];
    const pList  = Object.entries(params).map(([name, schema]) => `
      <div class="param-item">
        <div class="param-name">${esc(name)}</div>
        <div class="param-type">${esc(schema.type || 'any')} ${reqd.includes(name) ? '<span class="param-required">*</span>' : ''}</div>
      </div>`).join('');

    card.innerHTML = `
      <div class="tool-header">
        <div class="tool-info">
          <div class="tool-icon-container"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg></div>
          <div class="tool-details">
            <div class="tool-name">${esc(tool.name)}</div>
            <div class="tool-description">${esc(tool.description || '')}</div>
          </div>
        </div>
        ${pList ? `<button class="expand-btn" data-id="${esc(tool.name)}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="expand-icon"><polyline points="6 9 12 15 18 9"/></svg>
        </button>` : ''}
      </div>
      ${pList ? `<div class="tool-params" id="params-${esc(tool.name)}">
        <div class="params-title">Parameters:</div>
        <div class="params-grid">${pList}</div>
      </div>` : ''}`;

    grid.appendChild(card);
  });

  qsa('.expand-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const id  = btn.dataset.id;
      const box = $(`params-${id}`);
      const ico = btn.querySelector('.expand-icon');
      const open = box.classList.toggle('expanded');
      ico.style.transform = open ? 'rotate(180deg)' : '';
    });
  });
}

// ── Swarm ─────────────────────────────────────────────────────────────────────

$('swarm-run').addEventListener('click', runSwarm);
$('swarm-clear').addEventListener('click', () => {
  $('swarm-log').classList.remove('visible');
  $('swarm-result').classList.remove('visible');
  $('subtask-wrap').style.display = 'none';
  $('swarm-goal').value = '';
  state.swarmRunning = false;
  $('swarm-run').disabled = false;
});

async function runSwarm() {
  const goal = $('swarm-goal').value.trim();
  if (!goal) return;
  if (state.swarmRunning) return;

  state.swarmRunning = true;
  $('swarm-run').disabled = true;
  $('swarm-log').classList.add('visible');
  $('swarm-log').innerHTML = '';
  $('swarm-result').classList.remove('visible');
  $('subtask-wrap').style.display = 'none';

  logSwarm('phase', '⬡ Decomposing task…');

  // Poll progress while running
  const pollId = setInterval(async () => {
    const r = await msg({ action: 'getSwarmProgress' });
    if (r.success && r.progress?.length) {
      const latest = r.progress[r.progress.length - 1];
      handleSwarmEvent(latest);
    }
  }, 600);

  const res = await msg({ action: 'swarmRun', goal });
  clearInterval(pollId);

  state.swarmRunning = false;
  $('swarm-run').disabled = false;

  if (res.success) {
    logSwarm('done', '✓ Complete');
    $('swarm-result').textContent = res.result.summary;
    $('swarm-result').classList.add('visible');

    // Show subtask status pills
    if (res.result.results?.length) {
      $('subtask-wrap').style.display = 'flex';
      $('subtask-list').innerHTML = res.result.results.map(r => `
        <div class="subtask-pill">
          <div class="st-dot ${r.status === 'success' ? 'done' : 'error'}"></div>
          <span style="flex:1;font-size:12px">${esc(r.id)}: ${esc((res.result.subtasks?.find(s => s.id === r.id)?.description || '').slice(0, 60))}</span>
          <span style="color:var(--text-tertiary);font-size:11px">${r.model?.split('/').pop() || ''}</span>
        </div>`).join('');
    }
  } else {
    logSwarm('error', `✗ ${res.error}`);
    toast(res.error, 'error');
  }
}

function handleSwarmEvent(ev) {
  if (!ev) return;
  if (ev.type === 'phase')         logSwarm('phase', `[${ev.phase}] ${ev.message}`);
  else if (ev.type === 'subtask_start') logSwarm('info',  `  ↳ Agent ${ev.id} → ${ev.model?.split('/').pop() || ev.model}`);
  else if (ev.type === 'subtask_done')  logSwarm('done',  `  ✓ Agent ${ev.id} (${ev.ms}ms)`);
  else if (ev.type === 'subtask_error') logSwarm('error', `  ✗ Agent ${ev.id}: ${ev.error}`);
  else if (ev.type === 'done')          logSwarm('done', ev.message);
  else if (ev.type === 'error')         logSwarm('error', ev.message);
}

function logSwarm(type, text) {
  const log = $('swarm-log');
  const line = document.createElement('div');
  line.className = type === 'phase' ? 'log-phase' : type === 'error' ? 'log-error' : type === 'done' ? 'log-done' : 'log-info';
  line.textContent = text;
  log.appendChild(line);
  log.scrollTop = log.scrollHeight;
}

// ── Quick-Setup MCP (mcpnyx-u) ─────────────────────────────────────────────────

// Collapsible advanced section
$('qs-adv-toggle').addEventListener('click', () => {
  const body = $('qs-adv-body');
  const icon = $('qs-adv-icon');
  const open = body.classList.toggle('open');
  icon.style.transform = open ? 'rotate(180deg)' : '';
});

// Env vars
$('qs-env-add').addEventListener('click', () => {
  const k = $('qs-env-key').value.trim();
  const v = $('qs-env-val').value.trim();
  if (!k) return;
  state.qsEnv[k] = v;
  $('qs-env-key').value = '';
  $('qs-env-val').value = '';
  renderQsEnv();
});

function renderQsEnv() {
  const list = $('qs-env-list');
  const entries = Object.entries(state.qsEnv);
  if (entries.length === 0) {
    list.innerHTML = '<div style="padding:8px 10px; color:var(--text-tertiary); font-size:12px; font-style:italic">No env vars</div>';
    return;
  }
  list.innerHTML = entries.map(([k, v]) => `
    <div class="kv-row">
      <span class="kv-key">${esc(k)}</span>
      <span class="kv-val">${esc(v || '—')}</span>
      <button class="kv-del" data-key="${esc(k)}" title="Remove">×</button>
    </div>`).join('');
  list.querySelectorAll('.kv-del').forEach(btn => {
    btn.addEventListener('click', () => { delete state.qsEnv[btn.dataset.key]; renderQsEnv(); });
  });
}

// Args
$('qs-arg-add').addEventListener('click', () => addQsArg($('qs-arg-input')));
$('qs-arg-input').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addQsArg($('qs-arg-input')); } });

function addQsArg(input) {
  const v = input.value.trim();
  if (!v) return;
  state.qsArgs.push(v);
  input.value = '';
  renderQsArgs();
}

function renderQsArgs() {
  $('qs-arg-list').innerHTML = state.qsArgs.map((a, i) => `
    <div class="arg-tag">
      <span>${esc(a)}</span>
      <button data-i="${i}" title="Remove">×</button>
    </div>`).join('');
  $('qs-arg-list').querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => { state.qsArgs.splice(Number(btn.dataset.i), 1); renderQsArgs(); });
  });
}

// Ping
$('qs-ping').addEventListener('click', async () => {
  const url  = buildQsUrl();
  setQsStatus('connecting', 'Pinging…');
  const res  = await msg({ action: 'mcpPing', baseUrl: url });
  if (res.alive) {
    setQsStatus('connected', `Reachable at ${url}`);
    toast('Server reachable ✓', 'success');
  } else {
    setQsStatus('', 'No response — is mcpnyx-u running?');
    toast('No response from server', 'error');
  }
});

// Connect
$('qs-connect').addEventListener('click', async () => {
  const url  = buildQsUrl();
  const name = $('qs-name').value.trim() || 'mcpnyx-u';

  if (!url) { showError('qs-error', 'Enter a valid URL'); return; }

  $('qs-connect').disabled = true;
  setQsStatus('connecting', 'Connecting…');

  const res = await msg({ action: 'mcpConnect', serverName: name, baseUrl: url });

  if (res.success) {
    state.connected[name] = true;
    state.tools = res.tools || [];
    renderTools();
    setQsStatus('connected', `Connected — ${res.tools?.length || 0} tools`);
    $('quick-tools').textContent = `${res.tools?.length || 0} tools`;
    $('quick-tools').style.display = res.tools?.length ? 'inline' : 'none';
    $('qs-disconnect').style.display = 'inline-flex';
    $('qs-connect').style.display = 'none';

    updateHeaderStatus(true);
    toast(`Connected to ${name} ✓`, 'success');

    // Auto-save to servers list if not already there
    if (!state.servers.find(s => s.url === url)) {
      autoSaveServer(name, url);
    }
  } else {
    setQsStatus('error', `Failed: ${res.error}`);
    showError('qs-error', res.error || 'Connection failed');
    toast('Connection failed', 'error');
  }
  $('qs-connect').disabled = false;
});

// Disconnect
$('qs-disconnect').addEventListener('click', async () => {
  const name = $('qs-name').value.trim() || 'mcpnyx-u';
  await msg({ action: 'mcpDisconnect', serverName: name });
  state.connected[name] = false;
  state.tools = [];
  renderTools();
  setQsStatus('', 'Disconnected');
  $('qs-disconnect').style.display = 'none';
  $('qs-connect').style.display = 'inline-flex';
  $('quick-tools').style.display = 'none';
  updateHeaderStatus(false);
  toast('Disconnected', 'info');
});

function buildQsUrl() {
  const base = $('qs-url').value.trim().replace(/\/$/, '');
  const port = $('qs-port').value.trim();
  return port ? `${base}:${port}` : base;
}

function setQsStatus(state_, text) {
  const dot = $('quick-dot');
  const msg_ = $('quick-msg');
  dot.className = `conn-dot ${state_}`;
  msg_.textContent = text;
}

function updateHeaderStatus(connected) {
  setDot($('header-dot'), connected ? '' : 'off');
  $('header-status') .textContent = connected ? 'MCP connected' : '—';
  setDot($('footer-dot'), connected ? '' : 'off');
  $('footer-status') .textContent = connected ? 'MCP active' : 'Nyx ready';
}

// ── Saved Servers ─────────────────────────────────────────────────────────────

$('add-server-btn').addEventListener('click', openAddPanel);
$('sv-cancel').addEventListener('click', closeAddPanel);
$('sv-save').addEventListener('click', saveServer);

// Env vars
$('sv-env-add').addEventListener('click', () => {
  const k = $('sv-env-key').value.trim();
  const v = $('sv-env-val').value.trim();
  if (!k) return;
  state.svEnv[k] = v;
  $('sv-env-key').value = '';
  $('sv-env-val').value = '';
  renderSvEnv();
});

// Args
$('sv-arg-add').addEventListener('click', () => addSvArg($('sv-arg-input')));
$('sv-arg-input').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addSvArg($('sv-arg-input')); } });

function addSvArg(input) {
  const v = input.value.trim();
  if (!v) return;
  state.svArgs.push(v);
  input.value = '';
  renderSvArgs();
}

function renderSvEnv() {
  const list = $('sv-env-list');
  const entries = Object.entries(state.svEnv);
  if (entries.length === 0) {
    list.innerHTML = '<div style="padding:8px 10px; color:var(--text-tertiary); font-size:12px; font-style:italic">No env vars</div>';
    return;
  }
  list.innerHTML = entries.map(([k, v]) => `
    <div class="kv-row">
      <span class="kv-key">${esc(k)}</span>
      <span class="kv-val">${esc(v || '—')}</span>
      <button class="kv-del" data-key="${esc(k)}" title="Remove">×</button>
    </div>`).join('');
  list.querySelectorAll('.kv-del').forEach(btn => {
    btn.addEventListener('click', () => { delete state.svEnv[btn.dataset.key]; renderSvEnv(); });
  });
}

function renderSvArgs() {
  $('sv-arg-list').innerHTML = state.svArgs.map((a, i) => `
    <div class="arg-tag">
      <span>${esc(a)}</span>
      <button data-i="${i}" title="Remove">×</button>
    </div>`).join('');
  $('sv-arg-list').querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => { state.svArgs.splice(Number(btn.dataset.i), 1); renderSvArgs(); });
  });
}

function openAddPanel(data = null) {
  const panel = $('add-server-panel');
  panel.classList.add('open');
  $('panel-title-text').textContent = data ? 'Edit Server' : 'Add Server';

  // Pre-fill if editing
  $('sv-name').value = data?.name || '';
  $('sv-url').value  = data?.url  || '';
  $('sv-cmd').value  = data?.command || '';
  state.svEnv  = { ...(data?.env  || {}) };
  state.svArgs = [...(data?.args || [])];
  renderSvEnv();
  renderSvArgs();
  $('sv-error').classList.remove('visible');
}

function closeAddPanel() {
  $('add-server-panel').classList.remove('open');
  state.editIndex = -1;
}

async function saveServer() {
  const name = $('sv-name').value.trim();
  const url  = $('sv-url').value.trim();
  if (!name || !url) { showError('sv-error', 'Name and URL are required'); return; }

  const server = {
    name, url,
    command: $('sv-cmd').value.trim(),
    env:     { ...state.svEnv },
    args:    [...state.svArgs],
  };

  if (state.editIndex >= 0) {
    state.servers[state.editIndex] = server;
  } else {
    state.servers.push(server);
  }

  await msg({ action: 'saveMcpServers', servers: state.servers });
  renderServers();
  closeAddPanel();
  toast(state.editIndex >= 0 ? 'Server updated ✓' : 'Server saved ✓', 'success');
}

function renderServers() {
  const list = $('server-list');
  if (state.servers.length === 0) {
    list.innerHTML = `<div class="empty-state">
      <div class="empty-icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/></svg></div>
      <div>No saved servers yet</div>
    </div>`;
    return;
  }

  list.innerHTML = '';
  state.servers.forEach((sv, i) => {
    const connected = !!state.connected[sv.name];
    const card = document.createElement('div');
    card.className = `server-card ${connected ? 'connected' : ''}`;
    card.innerHTML = `
      <div class="server-left">
        <h4>${esc(sv.name)}</h4>
        <div class="server-url">${esc(sv.url)}</div>
        ${sv.command ? `<div class="server-cmd">$ ${esc(sv.command.slice(0, 40))}</div>` : ''}
      </div>
      <div class="server-right">
        <span class="conn-badge ${connected ? 'connected' : 'disconnected'}">${connected ? 'connected' : 'off'}</span>
        <button class="btn btn-secondary btn-sm" data-action="connect" data-i="${i}">${connected ? 'Reconnect' : 'Connect'}</button>
        <button class="btn btn-ghost btn-sm" data-action="edit" data-i="${i}">Edit</button>
        <button class="btn btn-danger btn-sm" data-action="delete" data-i="${i}">✕</button>
      </div>`;
    list.appendChild(card);
  });

  // Wire buttons
  list.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const action = btn.dataset.action;
      const i      = Number(btn.dataset.i);
      const sv     = state.servers[i];
      if (action === 'connect') {
        btn.disabled = true;
        const res = await msg({ action: 'mcpConnect', serverName: sv.name, baseUrl: sv.url });
        if (res.success) {
          state.connected[sv.name] = true;
          state.tools = res.tools || [];
          renderTools();
          renderServers();
          updateHeaderStatus(true);
          toast(`Connected: ${sv.name} ✓`, 'success');
        } else {
          toast(`Failed: ${res.error}`, 'error');
        }
        btn.disabled = false;
      } else if (action === 'edit') {
        state.editIndex = i;
        openAddPanel(sv);
      } else if (action === 'delete') {
        if (!confirm(`Delete server "${sv.name}"?`)) return;
        state.servers.splice(i, 1);
        await msg({ action: 'saveMcpServers', servers: state.servers });
        renderServers();
        toast('Server removed', 'info');
      }
    });
  });
}

async function autoSaveServer(name, url) {
  state.servers.push({ name, url, command: $('qs-cmd').value.trim(), env: { ...state.qsEnv }, args: [...state.qsArgs] });
  await msg({ action: 'saveMcpServers', servers: state.servers });
  renderServers();
}

// ── Footer buttons ────────────────────────────────────────────────────────────

// ── Utilities ─────────────────────────────────────────────────────────────────

function esc(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
