@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ==============================================
echo  NYX MCP Setup for Windows
echo ==============================================
echo.

echo 1. Checking for Chrome browser...
set BROWSER_FOUND=0
where chrome >nul 2>&1 && set BROWSER_FOUND=1
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set BROWSER_FOUND=1
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set BROWSER_FOUND=1
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set BROWSER_FOUND=1
if exist "%ProgramFiles%\Mozilla Firefox\firefox.exe" set BROWSER_FOUND=1
if "%BROWSER_FOUND%"=="1" (
    echo   ✓ Supported browser detected
) else (
    echo   No supported browser found. NYX supports Chrome, Edge, or Firefox.
    echo   Download Chrome:  https://www.google.com/chrome/
    echo   Download Firefox: https://www.mozilla.org/firefox/
    pause
    exit /b 1
)

echo.
echo 2. Installing NYX Chrome extension...
echo   Please follow these steps manually:
echo   Chrome/Edge:
echo   1. Go to: chrome://extensions/   (Edge: edge://extensions/)
echo   2. Enable "Developer mode" (top-right toggle)
echo   3. Click "Load unpacked"
echo   4. Select the "chrome-extension" folder in this package
echo   Firefox:
echo   1. Go to: about:debugging#/runtime/this-firefox
echo   2. Click "Load Temporary Add-on..."
echo   3. Select manifest.json inside the chrome-extension folder
if exist "chrome-extension" (
    echo   ✓ Extension folder found in package
) else (
    echo   ⚠ Extension folder not found in package
    echo   You may need to download it separately
)

echo.
echo 3. Setting up NYX directory on Desktop...
set NYX_DIR=%USERPROFILE%\Desktop\nyx
if not exist "%NYX_DIR%" (
    mkdir "%NYX_DIR%"
    echo   ✓ Created nyx directory: %NYX_DIR%
) else (
    echo   ✓ NYX directory already exists: %NYX_DIR%
)

echo.
echo 4. Checking for Node.js and npm...
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo   ❌ Node.js not found. Please install Node.js 18+ from:
    echo   https://nodejs.org/
    pause
    exit /b 1
) else (
    echo   ✓ Node.js detected
)

where npm >nul 2>&1
if %errorlevel% neq 0 (
    echo   ⚠ npm not found in PATH (but Node.js is installed)
) else (
    echo   ✓ npm detected
)

echo.
echo 5. Setting up configuration...
if not exist "config.json" (
    echo   ❌ config.json not found in package
    echo   Please ensure config.json exists in this directory
    pause
    exit /b 1
)

REM Read the template config.json
set CONFIG_FILE=%NYX_DIR%\config.json

REM Need to escape backslashes for JSON (double them)
set NYX_DIR_ESCAPED=%NYX_DIR:\=\\\%

REM Use PowerShell to do proper JSON replacement
(
echo $config = Get-Content 'config.json' -Raw
echo $nyxDir = '%NYX_DIR%'
echo $nyxDirEscaped = $nyxDir -replace '\\\\', '\\\\\\\\'
echo $config = $config -replace 'NYX_DIR_PLACEHOLDER', $nyxDirEscaped
echo $config | Set-Content '%CONFIG_FILE%' -Encoding UTF8
) > "%TEMP%\update_config.ps1" 2>nul

powershell -ExecutionPolicy Bypass -File "%TEMP%\update_config.ps1" 2>nul

if %errorlevel% equ 0 (
    echo   ✓ Created config.json with absolute path: %NYX_DIR%
    del "%TEMP%\update_config.ps1" 2>nul
) else (
    echo   ⚠ PowerShell method failed, using simple replacement
    
    REM Simple backup method if PowerShell fails
    (
    echo {
    echo   "mcpServers": {
    echo     "filesystem": {
    echo       "command": "npx",
    echo       "args": ["-y", "@modelcontextprotocol/server-filesystem@latest", "%NYX_DIR_ESCAPED%"],
    echo       "type": "stdio"
    echo     },
    echo     "memory-cache": {
    echo       "command": "npx",
    echo       "args": ["@modelcontextprotocol/server-memory", "--cacheDir", "%NYX_DIR_ESCAPED%"],
    echo       "type": "stdio"
    echo     },
    echo     "playwright": {
    echo       "command": "npx",
    echo       "args": [
    echo         "-y",
    echo         "@playwright/mcp@latest",
    echo         "--headless"
    echo       ],
    echo       "type": "stdio"
    echo     },
    echo     "desktop-commander": {
    echo       "type": "stdio",
    echo       "command": "npx",
    echo       "args": ["-y", "@wonderwhy-er/desktop-commander@latest"]
    echo     },
    echo     "terminal-controller": {
    echo       "command": "uvx",
    echo       "args": ["terminal_controller"],
    echo       "type": "stdio"
    echo     },
    echo     "context7-mcp": {
    echo       "command": "npx",
    echo       "args": ["-y", "@upstash/context7-mcp"]
    echo     },
    echo     "sequentialthinking": {
    echo       "command": "npx",
    echo       "args": [
    echo         "-y",
    echo         "@modelcontextprotocol/server-sequential-thinking"
    echo       ],
    echo       "alwaysAllow": [
    echo         "sequentialthinking"
    echo       ]
    echo     }
    echo   }
    echo }
    ) > "%CONFIG_FILE%"
    
    echo   ✓ Created config.json (fallback method)
)

echo   ✓ Filesystem access restricted to this directory only

echo.
echo 6. Creating start and stop scripts...

REM Create start script
(
echo @echo off
echo chcp 65001 ^>nul
echo echo Starting NYX MCP Server...
echo echo.
echo cd /d "%%USERPROFILE%%\Desktop\nyx"
echo npx -y @alsania-io/mcpnyx@latest --config "%%USERPROFILE%%\Desktop\nyx\config.json" --outputTransport streamableHttp
echo pause
) > "%NYX_DIR%\nyx-start.bat"

echo   ✓ Created nyx-start.bat

REM Create stop script
(
echo @echo off
echo chcp 65001 ^>nul
echo echo Stopping NYX MCP Server...
echo echo.
echo taskkill /F /IM node.exe 2^>nul
echo echo NYX server stopped.
echo pause
) > "%NYX_DIR%\nyx-stop.bat"

echo   ✓ Created nyx-stop.bat

echo.
echo 7. Creating desktop shortcuts...
(
echo Set oWS = WScript.CreateObject("WScript.Shell")
echo sLinkFile = "%%USERPROFILE%%\Desktop\Start NYX.lnk"
echo Set oLink = oWS.CreateShortcut(sLinkFile)
echo oLink.TargetPath = "%%USERPROFILE%%\Desktop\nyx\nyx-start.bat"
echo oLink.WorkingDirectory = "%%USERPROFILE%%\Desktop\nyx"
echo oLink.Description = "Start NYX MCP Server"
echo oLink.Save
echo ) > "%TEMP%\create_shortcut.vbs"

cscript //nologo "%TEMP%\create_shortcut.vbs" 2>nul
if %errorlevel% equ 0 (
    echo   ✓ Created desktop shortcut: Start NYX.lnk
    del "%TEMP%\create_shortcut.vbs" 2>nul
) else (
    echo   ⚠ Could not create desktop shortcut (manual creation needed)
)

echo.
echo ==============================================
echo  SETUP COMPLETE
echo ==============================================
echo.
echo Next steps:
echo 1. Install the NYX Chrome extension (see step 2)
echo 2. Double-click "Start NYX.lnk" on your desktop to run the server
echo 3. Connect Chrome extension to the server
echo.
echo Security configuration:
echo • Filesystem access restricted to: %NYX_DIR%
echo • Desktop-commander uses allowed directories only
echo • All MCP servers run with minimal permissions
echo.
echo For manual start: Double-click nyx-start.bat in Desktop\nyx\
echo For manual stop: Double-click nyx-stop.bat in Desktop\nyx\
echo.
pause
