# NYX Control - Windows Setup

**Includes Nyx Control v4.0.4 + local MCP server.**

---

## ⚠️ READ THIS FIRST — IMPORTANT WARNING AND DISCLAIMER

**This package gives AI assistants real access to your computer.**

By installing and using NYX you acknowledge and agree that:

- **You use this software entirely at your own risk.** It is provided "AS IS", without warranty of any kind, express or implied, including but not limited to warranties of merchantability, fitness for a particular purpose, and non-infringement.
- **Alsania I/O is not liable for any damages** — including but not limited to data loss, file corruption, deleted files, system damage, security incidents, financial loss, or any direct, indirect, incidental, special, consequential, or punitive damages — arising from the installation, use, or misuse of this software or from any action taken by an AI model or MCP tool.
- **Desktop Commander can execute real system commands.** This includes creating, modifying, and deleting files, and running programs with your user privileges. An AI model can and will make mistakes. **Always review what an AI is about to do before allowing it to run.**
- **Playwright can control a web browser.** Do not use it while signed into accounts you would not want automated, and do not point it at sensitive services.
- **You are responsible for your own backups.** Keep backups of anything important before granting AI tools access to a directory.
- **You are responsible for complying with all applicable laws** and the terms of service of any platform you use this software with.

If you do not accept these terms, **do not install or use this software.** Delete the package.

---

## Quick Start

1. **Double-click `win-setup.bat`** to run setup.
   > Do **not** run as Administrator. NYX installs into your own user profile and needs no elevation. Running as Administrator is unnecessary and gives the server more privilege than it needs.
2. **Install the browser extension** (see *Browser Installation* below).
3. **Start NYX:** double-click **Start NYX** on your Desktop.
4. **Connect:** click the NYX extension icon in your browser and connect to the local server.

## Browser Installation

The extension lives in the `chrome-extension\` folder inside this package. **Keep that folder somewhere permanent** — if you move or delete it, the extension breaks.

### Chrome / Edge (recommended)

1. Open your browser and go to `chrome://extensions/`
   (on Edge: `edge://extensions/`)
2. Turn on **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `chrome-extension` **folder** from this package (not a file inside it)
5. The NYX icon appears in your toolbar

> Chrome may show a "Disable developer mode extensions" warning on restart. This is normal for unpacked extensions — click **Keep** / **Cancel** to keep NYX enabled. Do not click "Disable".

### Firefox

1. Open Firefox and go to `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on…**
3. Select the `manifest.json` file **inside** the `chrome-extension` folder
4. NYX loads for this session

> **Firefox note:** temporarily loaded add-ons are removed when Firefox closes. You must reload it each session. This is a Firefox restriction for unpacked extensions, not a bug in NYX.

### Which browsers are not supported

Internet Explorer, legacy Edge, and most mobile browsers do **not** support unpacked extensions. If you want NYX on a phone, use the separate **Nyx Mobile** package with Firefox Mobile.

## Detailed Steps

### Prerequisites
- Windows 10 or 11
- A supported browser (Chrome, Edge, or Firefox)
- **Node.js 18+** (checked by the setup script)

### What the setup script does
1. Checks for a supported browser and Node.js
2. Creates `%USERPROFILE%\Desktop\nyx`
3. Writes a `config.json` with filesystem access **restricted to the nyx folder only**
4. Creates `nyx-start.bat` and `nyx-stop.bat`
5. Creates a **Start NYX** shortcut on your Desktop

### Running the server

**Start:** double-click **Start NYX** on your Desktop (or `nyx-start.bat` in `Desktop\nyx\`)

**Stop:** double-click `nyx-stop.bat` in `Desktop\nyx\`, or close the terminal window

## Security

- Filesystem access is **restricted to `Desktop\nyx`** — the MCP filesystem server is not given access to your whole user profile or system drive.
- All MCP servers run with **your normal user privileges**. They do not run elevated.
- **Desktop Commander still has real system access** within that scope and can run commands. Review AI actions before approving them.
- If Windows Firewall prompts, allow **local/private network** access only.

## Troubleshooting

### "Node.js not found"
Download and install Node.js 18+ from [nodejs.org](https://nodejs.org/), then **close and reopen** the setup window so the PATH refreshes.

### Setup window closes immediately
Right-click `win-setup.bat` → **Edit**, or open Command Prompt in the folder and run it there so you can read the error output:
```cmd
win-setup.bat
```

### Browser does not find the extension
- Make sure you selected the **folder** `chrome-extension`, not a file inside it
- Confirm `chrome-extension\manifest.json` exists
- For Firefox, load `manifest.json`, not the folder

### Server will not start
1. Check Node: `node --version` (must be 18 or newer)
2. Make sure no other NYX server is already running (`nyx-stop.bat` first)
3. Allow local connections through Windows Firewall

## Manual command

If the scripts do not work, run the server directly:
```cmd
cd %USERPROFILE%\Desktop\nyx
npx -y @alsania-io/mcpnyx@latest --config config.json --outputTransport streamableHttp
```

## Included tools

- **Filesystem** — file access restricted to `Desktop\nyx`
- **Desktop Commander** (`@wonderwhy-er/desktop-commander`) — system commands and file operations
- **Playwright** (`@playwright/mcp`) — browser automation (runs **headless** by default; edit `config.json` and remove `--headless` to watch it work)
- **Memory Cache** — store and recall information
- **Sequential Thinking** — structured problem-solving
- **Context7** — documentation lookup

## Support

Issues and questions: contact the Alsania development team.

---
**NYX Control — Windows Package**
*Bundles Nyx Control v4.0.4 — Alsania I/O sovereign AI infrastructure*
*Use at your own risk. See the warning at the top of this file.*
