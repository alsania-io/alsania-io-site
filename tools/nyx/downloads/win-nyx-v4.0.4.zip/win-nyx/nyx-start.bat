@echo off
chcp 65001 >nul
echo ==============================================
echo  NYX MCP Server - Windows
echo ==============================================
echo.
echo Starting NYX MCP Server...
echo Server will run in this window.
echo Press Ctrl+C to stop the server.
echo.

cd /d "%~dp0"

REM Check if config exists
if not exist "config.json" (
    echo ❌ ERROR: config.json not found in current directory
    echo Please run win-setup.bat first to set up NYX
    pause
    exit /b 1
)

REM Check Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ ERROR: Node.js not found. Please install Node.js 18+
    echo Download from: https://nodejs.org/
    pause
    exit /b 1
)

echo ✓ Node.js detected
echo ✓ Starting NYX MCP Server...
echo.
echo ==============================================
echo  SERVER LOGS START
echo ==============================================
echo.

npx -y @alsania-io/mcpnyx@latest --config "config.json" --outputTransport streamableHttp

echo.
echo ==============================================
echo  SERVER STOPPED
echo ==============================================
echo.
pause
