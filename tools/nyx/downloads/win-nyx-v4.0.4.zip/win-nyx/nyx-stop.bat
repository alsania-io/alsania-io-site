@echo off
chcp 65001 >nul
echo ==============================================
echo  NYX MCP Server - Stop Script
echo ==============================================
echo.
echo Stopping all NYX MCP servers...
echo.

taskkill /F /IM node.exe 2>nul
if %errorlevel% equ 0 (
    echo ✓ Stopped all Node.js processes (NYX servers)
) else (
    echo ✓ No running Node.js processes found
)

echo.
echo To start NYX again, run nyx-start.bat
echo.
pause
